

// welcome hover//
$('#title').hover(function () {
	$('#title').fadeOut(3000, function() {

	});
});

// here hover show //


$('.here1').mouseover(function(){
	$('#sur1').css("opacity",1);
})

$('.here1').mouseout(function(){
	$('#sur1').css("opacity",0);
})


$('.here2').mouseover(function(){
	$('#sur2').css("opacity",1);
})

$('.here2').mouseout(function(){
	$('#sur2').css("opacity",0);
})


$('.here3').mouseover(function(){
	$('#sur3').css("opacity",1);
})

$('.here3').mouseout(function(){
	$('#sur3').css("opacity",0);
})


$('.here4').mouseover(function(){
	$('#sur4').css("opacity",1);
})

$('.here4').mouseout(function(){
	$('#sur4').css("opacity",0);
})


$('.here5').mouseover(function(){
	$('#sur1').css("opacity",1);
	$('#sur2').css("opacity",1);
	$('#sur3').css("opacity",1);
	$('#sur4').css("opacity",1);
})

$('.here1').hover(function (){
	$(this).css("color", "white");
}, function() {
	$(this).css("color", "red");
});


$('.here2').hover(function ()
{$(this).css("color", "white");},
 function() {$(this).css("color", "red");});
		

$('.here3').hover(function (){
	$(this).css("color", "white");
}, function() {
	$(this).css("color", "red");
});


$('.here4').hover(function (){
	$(this).css("color", "white");
}, function() {
	$(this).css("color", "red");
});


$('.here5').hover(function (){
	$(this).css("color", "white");
}, function() {
	$(this).css("color", "red");
});


